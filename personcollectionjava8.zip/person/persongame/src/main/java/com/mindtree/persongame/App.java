package com.mindtree.persongame;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Collectors;

import com.mindtree.persongame.entity.Creator;
import com.mindtree.persongame.entity.Game;
import com.mindtree.persongame.entity.Person;

public class App {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		List<String> hobbies1 = new ArrayList<>();
		Set<Creator> creators = new HashSet<>();
		Map<Game, Set<Creator>> game = new TreeMap<>();
		Map<Person, Map<Game, Set<Creator>>> person = new HashMap<>();

		hobbies1.add("reading books");
		hobbies1.add("cricket");
		hobbies1.add("watching movies");
		Collections.sort(hobbies1);

		List<String> hobbies2 = new ArrayList<>();
		hobbies2.add("indoor games");
		hobbies2.add("chess");
		hobbies2.add("poetry");
		Collections.sort(hobbies2);

		creators.add(new Creator(1, "sai", hobbies1));
		creators.add(new Creator(2, "Unisoft", hobbies2));

		game.put(new Game(1, "clash of clanes", 6540), creators);
		game.put(new Game(2, "mario", 12500), creators);

		person.put(new Person(1, "rahul"), game);

		System.out.println();

		System.out.println("....................Game price greater than 500...............");
		game.entrySet().stream().filter(k -> k.getKey().getGamePrice() > 500).forEach(i -> {
			System.out.println(i.getKey().getGameName() + " " + i.getKey().getGamePrice());
			i.getValue().forEach(j -> {
				if (j.getCreatorName().equalsIgnoreCase("Ubisoft")) {
					System.out.println("CreatorName:   " + j);
				}
			});
		});
		int avg = game.entrySet().stream().filter(k -> k.getKey().getGamePrice() > 500)
				.filter(x -> x.getValue().stream().filter(y -> y.getCreatorName().equalsIgnoreCase("Ubisoft"))
						.collect(Collectors.toSet()).size() > 0)
				.reduce(0, (sum, r) -> r.getKey().getGamePrice() + sum, Integer::sum) / game.entrySet().size();

		System.out.println();
		System.out.println("............");
		System.out.println();
		person.entrySet().forEach(i -> {
			System.out.println("Person Name:" + i.getKey().getPersonName());
			i.getValue().entrySet().forEach(j -> {
				System.out.println(
						"Game Name:" + j.getKey().getGameName() + " " + " GamePrice:" + j.getKey().getGamePrice());
				j.getValue().forEach(k -> {
					System.out.println(k.getCreatorName() + " Hobbies:->" + k.getHobbies());
				});

			});
		});
		System.out.println();
		System.out.println("Average Game Price:" + avg);
	}

}
