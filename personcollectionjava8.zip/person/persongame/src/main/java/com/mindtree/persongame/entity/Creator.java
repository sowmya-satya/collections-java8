package com.mindtree.persongame.entity;

import java.util.List;

public class Creator {

	private int creatorId;
	private String creatorName;
	private List<String> hobbies;

	public Creator() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Creator(int creatorId, String creatorName, List<String> hobbies) {
		super();
		this.creatorId = creatorId;
		this.creatorName = creatorName;
		this.hobbies = hobbies;
	}

	public int getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(int creatorId) {
		this.creatorId = creatorId;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public List<String> getHobbies() {
		return hobbies;
	}

	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}

	@Override
	public String toString() {
		return "Creator [creatorId=" + creatorId + ", creatorName=" + creatorName + ", hobbies=" + hobbies + "]";
	}

	
}
