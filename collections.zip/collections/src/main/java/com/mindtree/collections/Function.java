package com.mindtree.collections;

import java.util.List;

import com.mindtree.collections.entity.Adult;

public interface Function {

	public static int getAdultsOnSalary(List<Adult> adult) {
		int total = adult.stream().reduce(0, (sum, i) -> sum + i.getSalary(), Integer::sum);
		return total;
	}
}
