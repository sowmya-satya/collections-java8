package com.mindtree.collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.mindtree.collections.entity.Adult;
import com.mindtree.collections.entity.Brand;
import com.mindtree.collections.entity.Model;
import com.mindtree.collections.entity.Phone;
import com.mindtree.collections.entity.User;

public class App {
	public static void main(String[] args) {

		Map<User, Phone> user = new HashMap<>();
		Map<User, Phone> user1 = new HashMap<>();

		Map<Model, Map<User, Phone>> model = new HashMap<>();

		Map<Brand, Map<Model, Map<User, Phone>>> brands = new HashMap<>();

		Phone phone = new Phone(1, 1234566);
		Phone phone1 = new Phone(2, 2345678);

		Phone phone2 = new Phone(3, 97658765);
		Phone phone3 = new Phone(4, 987698765);

		user.put(new User(1, "user1", 22, 25000), phone);
		user.put(new User(2, "user2", 25, 32000), phone1);

		user.put(new User(3, "user3", 32, 35000), phone2);
		user.put(new User(4, "user4", 35, 42000), phone3);

		model.put(new Model(1, "iphoneS"), user);
		model.put(new Model(2, "iphoneXS"), user1);

		brands.put(new Brand(1, "apple"), model);
		/*
		 * brands.entrySet().forEach(i -> {
		 * 
		 * System.out.println("=====" + i.getKey().getBrandName() + "=======");
		 * i.getValue().entrySet().forEach(j -> { System.out.println("=======" +
		 * j.getKey().getModelName() + "====="); j.getValue().entrySet().forEach(k -> {
		 * System.out.println(k.getKey().getUserName() + ":");
		 * System.out.println(k.getValue().getPhoneNo()); });
		 * 
		 * }); });
		 * 
		 * System.out.println();
		 */

		List<User> users = user.keySet().stream().filter(i -> i.getAge() > 18).collect(Collectors.toList());

		List<Adult> adults = users.stream().map(i -> convertToUser(i)).collect(Collectors.toList());

		List<Adult> adults1 = adults.stream().filter(i -> i.getAge() > 25 && i.getSalary() < 100000)
				.collect(Collectors.toList());

		System.out.println(adults1);

		System.out.println("Total Salary:" + Function.getAdultsOnSalary(adults1));

	}

	private static Adult convertToUser(User u) {
		return new Adult(u.getUserId(), u.getUserName(), u.getAge(), u.getSalary());
	}
}