package com.mindtree.collections.entity;

public class Adult {

	private int adultId;
	private String adultName;
	private int age;
	private int salary;

	public Adult() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Adult(int adultId, String adultName, int age, int salary) {
		super();
		this.adultId = adultId;
		this.adultName = adultName;
		this.age = age;
		this.salary = salary;
	}

	public int getAdultId() {
		return adultId;
	}

	public void setAdultId(int adultId) {
		this.adultId = adultId;
	}

	public String getAdultName() {
		return adultName;
	}

	public void setAdultName(String adultName) {
		this.adultName = adultName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Adult [adultId=" + adultId + ", adultName=" + adultName + ", age=" + age + ", salary=" + salary + "]";
	}

}
