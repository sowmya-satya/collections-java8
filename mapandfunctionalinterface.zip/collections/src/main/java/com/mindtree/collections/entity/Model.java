package com.mindtree.collections.entity;

public class Model implements Comparable<Model> {

	private int modelId;
	private String modelName;

	public Model() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Model(int modelId, String modelName) {
		super();
		this.modelId = modelId;
		this.modelName = modelName;
	}

	public int getModelId() {
		return modelId;
	}

	public void setModelId(int modelId) {
		this.modelId = modelId;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	@Override
	public String toString() {
		return "Model [modelId=" + modelId + ", modelName=" + modelName + "]";
	}

	@Override
	public int compareTo(Model m) {
		// TODO Auto-generated method stub
		if (this.modelName.compareToIgnoreCase(m.getModelName()) > 0) {
			return -1;
		} else {
			return 1;
		}
	}

}
