package com.mindtree.collections.entity;

public class Phone {

	private int phoneId;
	private long phoneNo;

	public Phone() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Phone(int phoneId, long phoneNo) {
		super();
		this.phoneId = phoneId;
		this.phoneNo = phoneNo;
	}

	public int getPhoneId() {
		return phoneId;
	}

	public void setPhoneId(int phoneId) {
		this.phoneId = phoneId;
	}

	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Phone [phoneId=" + phoneId + ", phoneNo=" + phoneNo + "]";
	}

}
